# -*- coding: utf-8 -*-

import re
import sys
import urllib
import urlparse
import time

from channelselector import get_thumb
from core import httptools
from core import scrapertools
from core import servertools
from core.item_ext import ItemExt as Item
from platformcode import config, logger
from core import tmdb
from lib import generictools
from channels import filtertools
from channels import autoplay

# IDIOMAS = {'CAST': 'Castellano', 'LAT': 'Latino', 'VO': 'Version Original'}
# IDIOMAS = {'Castellano': 'CAST', 'Latino': 'LAT', 'Version Original': 'VO'}
# list_language = IDIOMAS.values()
list_quality = []
list_servers = ['torrent']

host = "https://ilcorsaronero.cc/"
channel = "ilcorsaronero"


def mainlist(item):
    logger.info()

    itemlist = []

    thumb_pelis = get_thumb("channels_movie.png")
    thumb_pelis_hd = get_thumb("channels_movie_hd.png")
    thumb_series = get_thumb("channels_tvshow.png")
    thumb_series_hd = get_thumb("channels_tvshow_hd.png")
    thumb_buscar = get_thumb("search.png")
    thumb_separador = get_thumb("next.png")
    thumb_settings = get_thumb("setting_0.png")

    autoplay.init(item.channel, list_servers, list_quality)

    itemlist.append(Item(channel=item.channel, action="submenu", title="Film", url=host + "cat/1", extra="movie",
                         thumbnail=thumb_pelis))

    # Buscar películas
    itemlist.append(
        Item(channel=item.channel, action="search", title="Cerca Film", url=host, extra="movie",
             thumbnail=thumb_buscar))

    autoplay.show_option(item.channel, itemlist)  # Activamos Autoplay

    return itemlist


def submenu(item):
    logger.info()
    itemlist = []

    thumb_buscar = get_thumb("search.png")

    data = ''
    try:
        data = httptools.downloadpage(item.url).data
    except:
        pass

    if not data:
        logger.error("ERROR 01: SUBMENU: La Web no responde o ha cambiado de URL: " + item.url)
        itemlist.append(item.clone(action='',
                                   title=item.channel.capitalize() + ': ERROR 01: La Web no responde o ha cambiado de URL. Si la Web está activa, reportar el error con el log'))
        return itemlist  # Algo no funciona, pintamos lo que tenemos

    else:
        patron = r'class=\"tab\"\sHREF=\"([^\"]+)\"\s>(.*?)<'
        matches = re.compile(patron, re.MULTILINE).findall(data)
        for scrapedurl, scrapedtitle in matches:
            title = re.sub('\r\n', '', scrapedtitle).decode('utf8').encode('utf8').strip()
            itemlist.append(item.clone(action="findvideos", title=title, url=scrapedurl, extra=item.extra))

        regex = r'&nbsp;<a\shref=\"([^\"]+)\">.*?successive'
        nextpage = re.compile(regex, re.MULTILINE).findall(data)

        if nextpage[0]:
            scrapedtitle = "[COLOR orange]Successivo>>[/COLOR]"
            itemlist.append(
                Item(channel=item.channel,
                     action="submenu",
                     title=scrapedtitle,
                     url= host + nextpage[0],
                     thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/next_1.png",
                     extra="movie",
                     plot=""))
            itemlist.append(
                Item(channel=item.channel,
                     action="HomePage",
                     title="[COLOR yellow]Torna Home[/COLOR]",
                     folder=True))


    return itemlist


def findvideos(item):
    logger.info()

    itemlist = []




    return itemlist


def find_torrent_alt(item):
    logger.info()

    if not item.emergency_urls:
        return item

    i = 0
    for lang, quality, size, scrapedurl in item.emergency_urls[
        1]:  # buscamos la url actual en la lista de matches cacheada
        if item.url == scrapedurl:  # si está ...
            item.torrent_alt = item.emergency_urls[0][i]  # ... copiamos la url o la dirección de .torrent local
            break  # ... y nos vamos
        i += 1

    return item


def search(item, texto):
    logger.info("texto:" + texto)
    texto = texto.replace(" ", "+")
    itemlist = []

    item.url = "%s?s=%s" % (item.url, texto)
    item.media = "search"  # Marcar para "Listado": igual comportamiento que "Categorías"

    try:
        if "series/" in item.url:
            item.extra = "series"
            item.title = "Series"
        else:
            item.extra = "peliculas"
            item.title = "Películas"

        itemlist = listado(item)

        return itemlist

    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("ERROR: %s: SEARCH" % line)
        return []
