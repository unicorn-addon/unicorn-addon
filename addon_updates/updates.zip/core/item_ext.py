from core.item import Item
from core import scrapertools
from core.tmdb import Tmdb
from platformcode import logger


class ItemExt(Item):
    def __init__(self, **kwargs):
        super(ItemExt, self).__init__(**kwargs)

        if self.extra == "serie" or self.extra == "movie":
            self.normalize_item()

    def normalize_item(self):
        logger.info("unicorn.core.item_ext normalize_item")
        logger.info(
            "channel=[" + self.channel + "], action=[" + self.action + "], title=[" + self.title + "], url=[" + self.url + "], thumbnail=[" + self.thumbnail + "], tipo=[" + self.extra + "]")
        try:
            tmdbtitle = \
                self.fulltitle.split("|")[0].split("{")[0].split("[")[0].split("(")[0].split("Sub-ITA")[0].split(
                    "Sub ITA")[
                    0].split("20")[0].split("19")[0].split("S0")[0].split("Serie")[0].split("HD ")[0]
            year = scrapertools.find_single_match(self.fulltitle, '\((\d{4})\)')

            tipo = "movie" if self.extra == "movie" else "tv"

            otmdb = Tmdb(texto_buscado=tmdbtitle,
                         tipo=tipo,
                         idioma_busqueda='it',
                         year=year)

            # self.title = self.title + "[COLOR yellow] [" + self.channel.capitalize() + "][/COLOR]"
            self.infoLabels = otmdb.get_infoLabels(self.infoLabels)
            if 'thumbnail' in self.infoLabels:
                self.thumbnail = self.infoLabels['thumbnail']
            if 'fanart' in self.infoLabels:
                self.fanart = self.infoLabels['fanart']

        except:
            pass
