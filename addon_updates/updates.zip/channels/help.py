# -*- coding: utf-8 -*-

import os

from core.item import Item
from platformcode import config, logger, platformtools
from channelselector import get_thumb

if config.is_xbmc():

    import xbmcgui

    class TextBox(xbmcgui.WindowXMLDialog):
        """ Create a skinned textbox window """
        def __init__(self, *args, **kwargs):
            self.title = kwargs.get('title')
            self.text = kwargs.get('text')
            self.doModal()

        def onInit(self):
            try:
                self.getControl(5).setText(self.text)
                self.getControl(1).setLabel(self.title)
            except:
                pass

        def onClick(self, control_id):
            pass

        def onFocus(self, control_id):
            pass

        def onAction(self, action):
            # self.close()
            if action in [xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK]:
                self.close()


def mainlist(item):
    logger.info()
    itemlist = []

    itemlist.append(Item(channel=item.channel, action="", title="FAQ:",
                         thumbnail=get_thumb("help.png"),
                         folder=False))
    if config.is_xbmc():
        itemlist.append(Item(channel=item.channel, action="faq",
                             title="    - Come segnalare un errore?",
                             thumbnail=get_thumb("help.png"),
                             folder=False, extra="report_error"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - È possibile abilitare / disabilitare i canali?",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="onoff_canales"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - La sincronizzazione automatica è possibile con Trakt?",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="trakt_sync"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - È possibile mostrare tutti i risultati insieme nel motore di ricerca globale?",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="buscador_juntos"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - I link richiedono tempo per apparire.",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="tiempo_enlaces"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - La ricerca di contenuti non è eseguita correttamente.",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="prob_busquedacont"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - Alcuni canali non funzionano correttamente.",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="canal_fallo"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - I collegamenti Torrent non funzionano.",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra="prob_torrent"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - La libreria video non è stata aggiornata correttamente.",
                         thumbnail=get_thumb("help.png"),
                         folder=True, extra="prob_bib"))
    itemlist.append(Item(channel=item.channel, action="faq",
                         title="    - Collegamenti di interesse",
                         thumbnail=get_thumb("help.png"),
                         folder=False, extra=""))

    return itemlist


def faq(item):

    if item.extra == "onoff_canales":
        respuesta = platformtools.dialog_yesno("Unicorn",
                                               "Questo può essere fatto in 'Impostazioni'> Attiva / Disattiva i canali"
                                               "È possibile attivare / disattivare i canali uno alla volta o tutti allo stesso tempo",
                                               "Vuoi gestire i canali adesso?")
        if respuesta == 1:
            from channels import setting
            setting.conf_tools(Item(extra='channels_onoff'))

    elif item.extra == "trakt_sync":
        respuesta = platformtools.dialog_yesno("Unicorn",
                                               "La sincronizzazione corrente può essere attivata (silenziosa)"
                                               "Dopo aver contrassegnato come visto un episodio (questo viene fatto automaticamente)."
                                               "Questa opzione può essere attivata in 'Impostazioni' > 'Impostazioni'"
                                               "dalla libreria video",
                                               "Vuoi accedere a queste impostazioni?")
        if respuesta == 1:
            from channels import videolibrary
            videolibrary.channel_config(Item(channel='videolibrary'))

    elif item.extra == "tiempo_enlaces":
        respuesta = platformtools.dialog_yesno("Unicorn",
                                               "Questo può essere migliorato limitando il numero massimo di "
                                               "link o mostrandoli in una finestra pop-up. "
                                               "Queste opzioni sono in 'Impostazioni' > 'Impostazioni' "
                                               "dalla libreria video.",
                                               "Vuoi accedere a queste impostazioni?")
        if respuesta == 1:
            from channels import videolibrary
            videolibrary.channel_config(Item(channel='videolibrary'))

    elif item.extra == "prob_busquedacont":
        title = "Unicorn - FAQ - %s" % item.title[6:]
        text = ("Potrebbe non aver scritto correttamente il percorso della libreria in "
                "'Impostazioni' > 'Preferenze'.\n"
                "La rotta specificata deve essere esattamente uguale alla 'fonte' "
                "inserito in 'Archivi' della videoteca Kodi.\n"
                "AVANZATO: questa rotta si trova anche in 'sources.xml'. \n"
                "Potresti anche avere problemi di essere "
                "utilizzando alcuni fork di Kodi e percorsi con 'special://'. "
                "SPMC, ad esempio, ha problemi con questo, e sembra non avere alcuna soluzione, "
                "visto che è un problema estraneo ad Unicorn che esiste da molto tempo.\n"
                "Puoi provare a correggere questi problemi in 'Impostazioni' > 'Impostazioni' "
                "la 'libreria video', cambiando l'impostazione 'Esegui ricerca contenuto' in"
                "da 'La cartella di ogni serie' a 'Tutta la libreria video'."
                "Puoi anche chiedere aiuto a 'http://unicorn-addon.com")

        return TextBox("DialogTextViewer.xml", os.getcwd(), "Default", title=title, text=text)

    elif item.extra == "canal_fallo":
        title = "Unicorn - FAQ - %s" % item.title[6:]
        text = ("Può darsi che il sito web del canale non funzioni. "
                "Nel caso in cui il sito web funzioni, potresti non essere il primo"
                "nel vederlo e che il canale è fisso."
                "Puoi cercare in 'unicorn-addon.com' o "
                "Repository GitHub (github.com/unicorn-addon/addon)."
                "Se non riesci a trovare il canale organizzato, puoi segnalare un"
                "problema nel forum.")

        return TextBox("DialogTextViewer.xml", os.getcwd(), "Default", title=title, text=text)

    elif item.extra == "prob_bib":
        platformtools.dialog_ok("Unicorn",
                                "Probabilmente hai aggiornato il plugin di recente "
                                "e che gli aggiornamenti non sono stati applicati affatto "
                                "Beh, puoi provarlo in 'Impostazioni' > 'Altri strumenti', "
                                "controllando i file * _data.json o"
                                "Ri-aggiungere l'intera libreria video.")

        respuesta = platformtools.dialog_yesno("Unicorn",
                                               "Vuoi accedere a quella sezione ora?")
        if respuesta == 1:
            itemlist = []
            from channels import setting
            new_item = Item(channel="setting", action="submenu_tools", folder=True)
            itemlist.extend(setting.submenu_tools(new_item))
            return itemlist

    elif item.extra == "prob_torrent":
        title = "Unicorn - FAQ - %s" % item.title[6:]
        text = ("Puoi provare a scaricare il modulo 'libtorrent' da Kodi o"
                "installando un addon come 'Quasar' o 'Torrenter' , "
                "che apparirà tra le opzioni nella finestra pop-up "
                "che appare quando si fa clic su un collegamento torrent. "
                "'Torrenter' è più complesso ma anche più completo "
                "e funziona sempre.")

        return TextBox("DialogTextViewer.xml", os.getcwd(), "Default", title=title, text=text)

    elif item.extra == "buscador_juntos":
        respuesta = platformtools.dialog_yesno("Unicorn",
                                               "Sì, l'opzione per mostrare insieme i risultati "
                                               "o diviso per canali è in "
                                               "'setting'> 'Global search engine settings'>"
                                               "'Altre impostazioni'.",
                                               "Vuoi accedere a queste impostazioni ora?")
        if respuesta == 1:
            from channels import search
            search.settings("")

    elif item.extra == "report_error":
        import xbmc
        if config.get_platform(True)['num_version'] < 14:
            log_name = "xbmc.log"
        else:
            log_name = "kodi.log"
        ruta = xbmc.translatePath("special://logpath") + log_name
        title = "Unicorn - FAQ - %s" % item.title[6:]
        text = ("Per segnalare un problema in 'http://unicorn-addon.com' è necessario:\n"
                "  - Versione che usi da Unicorn.\n"
                "  - Versione che usi di Kodi, mediaserver, ecc.\n"
                "  - Versione e nome del sistema operativo che si utilizza.\n"
                "  - Nome della skin (se usi Kodi) e se "
                "Hai risolto il problema utilizzando lo skin predefinito.\n"
                "  - Descrizione del problema e alcuni casi di test.\n"
                "  - Aggiungi il registro in modalità dettagliata, una volta fatto questo, "
                "Scrivi il log e lo puoi allegare in un post.\n\n"
                "Per attivare il registro in modalità dettagliata, immettere:\n"
                "  - Configurazione.\n"
                "  - Preferenze.\n"
                "  - Nella scheda Generale - Segna l'opzione: Genera registro dettagliato.\n\n"
                "Il file di registro dettagliato si trova nel seguente percorso: \n\n"
                "%s" % ruta)

        return TextBox("DialogTextViewer.xml", os.getcwd(), "Default", title=title, text=text)

    else:
        platformtools.dialog_ok("Unicorn",
                                "Ulteriori informazioni su novità, suggerimenti o opzioni che non conosci su Telegram: @unicorn_addon.\n"
                                "Se hai problemi o dubbi, puoi andare al Forum: http://unicorn-addon.com")


