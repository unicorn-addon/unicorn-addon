# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Thegroove360 - XBMC Plugin
# Canale mediaempire
# ------------------------------------------------------------

import re
import urllib
import urlparse

from core import httptools
from platformcode import logger
from core import scrapertools
from core import servertools
from core.item_ext import ItemExt as Item
from platformcode import config

__channel__ = "mediaempire"
host = "https://mediaempire.me/"
headers = [['Referer', host]]


def mainlist(item):
    logger.info("[thegroove360.mediaempire] mainlist")
    itemlist = [Item(channel=__channel__,
                     title="[COLOR azure]Film[/COLOR]",
                     action="peliculas",
                     url="%s/movies/" % host,
                     extra="movie",
                     thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/popcorn_serie_P.png"),
                Item(channel=__channel__,
                     title="[COLOR azure]Film [COLOR orange]- Categorie[/COLOR]",
                     action="categorias",
                     url=host,
                     thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/genres_P.png"),
                Item(channel=__channel__,
                     title="[COLOR yellow]Cerca Film...[/COLOR]",
                     action="search",
                     extra="movie",
                     thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/search_P.png"),
                Item(channel=__channel__,
                     title="[COLOR azure]Serie TV[/COLOR]",
                     action="peliculas",
                     url="%s/serie-tv-streaming/" % host,
                     extra="tvshow",
                     thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/tv_series_P.png"),
                Item(channel=__channel__,
                     title="[COLOR yellow]Cerca Serie TV...[/COLOR]",
                     action="search",
                     extra="tvshow",
                     thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/search_P.png")]

    return itemlist


# ==================================================================================================================================================

def categorias(item):
    itemlist = []

    # Descarga la pagina
    data = httptools.downloadpage(item.url, headers=headers).data
    bloque = scrapertools.get_match(data, '<ul class="listSubCat" id="Film">(.*?)</ul>')

    # Extrae las entradas (carpetas)
    patron = '<li><a href="([^"]+)">(.*?)</a></li>'
    matches = re.compile(patron, re.DOTALL).findall(bloque)

    for scrapedurl, scrapedtitle in matches:
        scrapedurl = host + scrapedurl
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas",
                 title="[COLOR azure]" + scrapedtitle + "[/COLOR]",
                 url=scrapedurl,
                 thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/genre_P.png",
                 folder=True))

    return itemlist


# ==================================================================================================================================================

def search(item, texto):
    logger.info("[thegroove360.mediaempire] " + item.url + " search " + texto)
    item.url = host + "/?do=search&subaction=search&story=" + texto
    try:
        if item.extra == "movie":
            return peliculas(item)
        if item.extra == "tvshow":
            return peliculas(item)
    # Se captura la excepción, para no interrumpir al buscador global si un canal falla
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


# ==================================================================================================================================================

def login():
    payload = urllib.urlencode(
        {'action': 'dooplay_login', 'log': 'thepasto', 'pwd': '8NpAawX5pzY22DL', 'rmb': 'forever', 'red': host})
    res = httptools.downloadpage(host + 'ghost-administrators/ajax-call', post=payload).data

    print res

    return res


def peliculas(item):
    logger.info("[thegroove360.mediaempire] peliculas")
    itemlist = []
    login()

    # Descarga la pagina
    data = httptools.downloadpage(item.url, headers=headers).data

    print data

    patron = r'<article id=\"post-\d+.*?class=\"item movies\"><div class=\"poster\"><img src=(\"[^\"]+).*?class=\"rating\">.*?</span>\s(.*?)</div>.*?<h3><a href=\"([^\"]+)\">(.*?)</a>.*?<span>(.*?)</span>'
    matches = re.compile(patron, re.MULTILINE).findall(data)

    for scrapedthumbnail, scrapedvote, scrapedurl, scrapedtitle, scrapedyear in matches:
        scrapedplot = ""

        itemlist.append(
            Item(channel=__channel__,
                 action="findvideos",
                 contentType="movie",
                 fulltitle=scrapedtitle,
                 show=scrapedtitle,
                 title="[COLOR azure]" + scrapedtitle + "[/COLOR]",
                 url=scrapedurl,
                 extra=item.extra,
                 thumbnail=scrapedthumbnail,
                 plot=scrapedplot,
                 folder=True))

    # Extrae el paginador
    patronvideos = r"class=\"current\".*?<a class='arrow_pag' href=\"([^\"]+)\""
    matches = re.compile(patronvideos, re.MULTILINE).findall(data)

    if len(matches) > 0:
        scrapedurl = urlparse.urljoin(item.url, matches[0])
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas",
                 title="[COLOR orange]Successivi >>[/COLOR]",
                 url=scrapedurl,
                 extra=item.extra,
                 thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/next_1.png",
                 folder=True))

    return itemlist


# ==================================================================================================================================================

def peliculas_tv(item):
    logger.info("[thegroove360.mediaempire] peliculas")
    itemlist = []

    # Descarga la pagina
    data = httptools.downloadpage(item.url, headers=headers).data

    # Extrae las entradas (carpetas)
    # patron = r'<span class[^>]+>([^<]+)<\/span> <span class="ssound">([^<]+)</span>'
    patron = r'<a href="([^"]+)"><img src="([^"]+)" class="[^>]+" alt="([^<]+)"\s*height[^>]+>'
    matches = re.compile(patron, re.DOTALL).finditer(data)

    for match in matches:
        scrapedplot = ""
        scrapedtitle = scrapertools.unescape(match.group(5))
        scrapedthumbnail = urlparse.urljoin(item.url, match.group(4))
        scrapedurl = urlparse.urljoin(item.url, match.group(3))
        lang = scrapertools.unescape(match.group(2))
        quality = scrapertools.unescape(match.group(1))
        quality = " ([COLOR yellow]" + quality + "[/COLOR])"
        lang = lang.replace("Italiano", "ITA")
        lang = " ([COLOR yellow]" + lang + "[/COLOR])"
        itemlist.append(
            Item(channel=__channel__,
                 action="episodios",
                 contentType="tv",
                 fulltitle=scrapedtitle,
                 show=scrapedtitle,
                 title="[COLOR azure]" + scrapedtitle + "[/COLOR]" + quality + lang,
                 url=scrapedurl,
                 thumbnail=scrapedthumbnail,
                 plot=scrapedplot,
                 folder=True))

    # Extrae el paginador
    patronvideos = '<a href="([^"]+)">Avanti →</a>'
    matches = re.compile(patronvideos, re.DOTALL).findall(data)

    if len(matches) > 0:
        scrapedurl = urlparse.urljoin(item.url, matches[0])
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas_tv",
                 title="[COLOR orange]Successivi >>[/COLOR]",
                 url=scrapedurl,
                 thumbnail="https://raw.githubusercontent.com/stesev1/channels/master/images/channels_icon/next_1.png",
                 folder=True))

    return itemlist


# ==================================================================================================================================================

def episodios(item):
    logger.info("[thegroove360.mediaempire] episodios")

    itemlist = []

    data = httptools.downloadpage(item.url, headers=headers).data

    patron = '<small class="text-muted">\s*([^<]+)</small>\s*([^<]+)</div>\s*<div class=".*?">\s*'
    patron += '<div class=".*?">\s*<a href[^>]+link="([^"]+)"><small class[^>]+>\s*</small>[^<]+</a>'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedep, scrapedtitle, scrapedurl in matches:
        scrapedplot = ""
        scrapedthumbnail = ""
        scrapedtitle = scrapedtitle.replace('Stai guardando: ', '').replace("&nbsp;", "").strip()
        scrapedep = scrapedep.replace("ep", "Ep. ")

        itemlist.append(
            Item(channel=__channel__,
                 action="findvideos",
                 fulltitle=item.fulltitle + " - " + scrapedep + " - " + scrapedtitle,
                 show=item.show + " - " + scrapedep + " - " + scrapedtitle,
                 title="[COLOR azure]" + scrapedep + " - " + scrapedtitle + "[/COLOR]",
                 contentType="episode",
                 url=scrapedurl,
                 thumbnail=item.thumbnail,
                 plot="[COLOR orange]" + item.fulltitle + "[/COLOR] " + item.plot,
                 folder=True))

    if config.get_videolibrary_support() and len(itemlist) != 0:
        itemlist.append(
            Item(channel=__channel__,
                 title="Aggiungi alla libreria",
                 url=item.url,
                 action="add_serie_to_library",
                 extra="episodios",
                 show=item.show))
        itemlist.append(
            Item(channel=__channel__,
                 title="Scarica tutti gli episodi della serie",
                 url=item.url,
                 action="download_all_episodes",
                 extra="episodios",
                 show=item.show))

    return itemlist


# ==================================================================================================================================================

def findvideos(item):
    data = httptools.downloadpage(item.url).data
    patron = r"<li id='player-.*?'.*?class='dooplay_player_option'\sdata-type='(.*?)'\sdata-post='(.*?)'\sdata-nume='(.*?)'>.*?'title'>(.*?)</"
    matches = re.compile(patron, re.IGNORECASE).findall(data)

    itemlist = []

    for scrapedtype, scrapedpost, scrapednume, scrapedtitle in matches:
        itemlist.append(
            Item(channel=__channel__,
                 action="play",
                 fulltitle=item.title + " [" + scrapedtitle + "]",
                 show=scrapedtitle,
                 title="[COLOR azure]" + item.title + "[/COLOR] " + " [" + scrapedtitle + "]",
                 url="%swp-admin/admin-ajax.php" % host,
                 post=scrapedpost,
                 nume=scrapednume,
                 type=scrapedtype,
                 extra=item.extra,
                 folder=True))

    return itemlist


def play(item):
    payload = urllib.urlencode({'action': 'doo_player_ajax', 'post': item.post, 'nume': item.nume, 'type': item.type})
    data = httptools.downloadpage(item.url, post=payload).data

    patron = r"<iframe.*src='(([^']+))'\s"
    matches = re.compile(patron, re.IGNORECASE).findall(data)

    url = matches[0][0]

    print "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"
    #url = url.split("source=")[1]
    #url = urllib.unquote(url).decode('utf8')

    print url

    # return
    data = httptools.downloadpage(url, headers=headers).data

    print data

    regex = r'file\":\"([^\"]+)\"'
    url = scrapertools.find_single_match(data, regex)

    print "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC"
    data = url.replace("\/", "/")
    print data

    #return []

    # itemlist = servertools.find_video_items(data=data)
    itemlist = []
    itemlist.append(
        item.clone(title=item.title, action="play", url=url, thumbnail="", server="directo", folder=False))

    return itemlist

# ==================================================================================================================================================
# ==================================================================================================================================================
# ==================================================================================================================================================
'''	
def findvideos_tv(item):
    itemlist=[]
    data = httptools.downloadpage(item.url, headers=headers).data

    elemento = scrapertools.find_single_match(data, 'file: "(.*?)",')

    itemlist.append(Item(channel=__channel__,
                         action="play",
                         title=item.title,
                         url=elemento,
                         thumbnail=item.thumbnail,
                         fulltitle=item.fulltitle,
                         show=item.fulltitle))
    return itemlist'''
